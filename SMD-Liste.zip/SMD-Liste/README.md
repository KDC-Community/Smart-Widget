# Samsung Smart TV-Widget
# Stream Medial Deutschland 
# "Play-Listen"
#
# Die vorhandenen Listen sind Platzhalter und dienen der Information.

# Damit die Listen funktionieren, sollte man die Platzhalter "NNN/WWW" für Username und Passwort in funktionierende Logindaten ersetzen.

# Die Listen sollte man auf einem Webspace uploaden (bplaced oder github) und die "sam.xml" dementsprechend bearbeiten / anpassen (URL-Daten hinzufügen / bearbeiten.)
# und auch auf'm Webspace uploaden.
# zudem sollte man die "start.xml" bzgl. der Links anpassen, welche zur "sam.xml" führen...

# Die "sam.xml" kann auch als "sam.php" , oder "sam.m3u" , etc. hinzugefügt werden.

# Hierzu bitte die Widget / Addon ReadMe lesen! 
 
